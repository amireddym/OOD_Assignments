package edu.neu.cyse6200;

public class TigerAnimalistic implements AnimalisticAPI{

	@Override
	public void makeSound() {
		
		System.out.println("Making sound from TigerAnimalistic class");
	}
	
	@Override
	public String toString() {
		
		return "To String method from TigerAnimalistic class";
	}

}
