package edu.neu.cyse6200;

public class Driver {

	public static void main(String[] args) {
		
		System.out.println("Driver class Main method is Running ....");
		
		Zoo.demo();
	}

}
