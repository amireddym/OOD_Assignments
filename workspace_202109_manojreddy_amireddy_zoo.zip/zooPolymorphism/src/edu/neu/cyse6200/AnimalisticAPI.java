package edu.neu.cyse6200;

public interface AnimalisticAPI {
	
	public void makeSound();

}
