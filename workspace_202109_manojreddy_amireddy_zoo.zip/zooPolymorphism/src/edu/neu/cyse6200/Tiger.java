package edu.neu.cyse6200;

public class Tiger extends AnimalAPI{

	@Override
	public void makeSound() {
		
		System.out.println("Making sound from Tiger class");
	}
	
	@Override
	public String toString() {
		
		return "To String method from Tiger class";
	}
}
