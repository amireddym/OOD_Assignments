package edu.neu.cyse6200;

public abstract class AbstractStore {
	
	public abstract void demo();

}