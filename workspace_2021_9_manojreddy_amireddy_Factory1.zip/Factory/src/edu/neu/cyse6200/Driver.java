package edu.neu.cyse6200;

public class Driver {
	
	
	public static void main (String[] args) {
		
		AbstractStore store = new Store();
		store.demo();
	}

}
