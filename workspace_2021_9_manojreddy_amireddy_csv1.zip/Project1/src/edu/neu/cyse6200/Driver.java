package edu.neu.cyse6200;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CsvManager.demo();
		
		
//		Printing Students List data
//		13,24,manoj,reddy,venkat,amireddy,123,3.39
//		16,27,daniel,peters,rutherford,rick,132,3.13
//		11,20,ruthivk,verma,karthik,reddy,111,3.5
//		19,25,ramana,sastry,satish,acharya,199,3.97
//
//		Printing Teacher Object data
//		13,34,Anshita,Verma,Ravi,Verma,15.5
//
//		Students List before Sorting
//		Id,Age,FirstName,LastName,ParentFirstName,ParentLastName,StudentId,Gpa
//		13,24,manoj,reddy,venkat,amireddy,123,3.39
//		16,27,daniel,peters,rutherford,rick,132,3.13
//		11,20,ruthivk,verma,karthik,reddy,111,3.5
//		19,25,ramana,sastry,satish,acharya,199,3.97
//		15,30,shashank,Siripragada,adesham,sirigunda,124,3.9
//
//		Students List after Sorting by Id
//		Id,Age,FirstName,LastName,ParentFirstName,ParentLastName,StudentId,Gpa
//		11,20,ruthivk,verma,karthik,reddy,111,3.5
//		13,24,manoj,reddy,venkat,amireddy,123,3.39
//		15,30,shashank,Siripragada,adesham,sirigunda,124,3.9
//		16,27,daniel,peters,rutherford,rick,132,3.13
//		19,25,ramana,sastry,satish,acharya,199,3.97
//
//		Students List after Sorting by StudentId
//		Id,Age,FirstName,LastName,ParentFirstName,ParentLastName,StudentId,Gpa
//		11,20,ruthivk,verma,karthik,reddy,111,3.5
//		13,24,manoj,reddy,venkat,amireddy,123,3.39
//		15,30,shashank,Siripragada,adesham,sirigunda,124,3.9
//		16,27,daniel,peters,rutherford,rick,132,3.13
//		19,25,ramana,sastry,satish,acharya,199,3.97
//
//		Students List after Sorting by LastName
//		Id,Age,FirstName,LastName,ParentFirstName,ParentLastName,StudentId,Gpa
//		16,27,daniel,peters,rutherford,rick,132,3.13
//		13,24,manoj,reddy,venkat,amireddy,123,3.39
//		19,25,ramana,sastry,satish,acharya,199,3.97
//		15,30,shashank,Siripragada,adesham,sirigunda,124,3.9
//		11,20,ruthivk,verma,karthik,reddy,111,3.5
//
//		Students List after Sorting by FirstName
//		Id,Age,FirstName,LastName,ParentFirstName,ParentLastName,StudentId,Gpa
//		16,27,daniel,peters,rutherford,rick,132,3.13
//		13,24,manoj,reddy,venkat,amireddy,123,3.39
//		19,25,ramana,sastry,satish,acharya,199,3.97
//		11,20,ruthivk,verma,karthik,reddy,111,3.5
//		15,30,shashank,Siripragada,adesham,sirigunda,124,3.9
//
//		Students List after Sorting by Gpa
//		Id,Age,FirstName,LastName,ParentFirstName,ParentLastName,StudentId,Gpa
//		16,27,daniel,peters,rutherford,rick,132,3.13
//		13,24,manoj,reddy,venkat,amireddy,123,3.39
//		11,20,ruthivk,verma,karthik,reddy,111,3.5
//		15,30,shashank,Siripragada,adesham,sirigunda,124,3.9
//		19,25,ramana,sastry,satish,acharya,199,3.97
	}

}
