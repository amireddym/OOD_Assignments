package edu.neu.csye6200;

public class Driver {

	public static void main(String[] args) {
		
		DataStructureSample.demo();

//		Checking Stack with Integer Array
//		Pushing item on to the stack
//		Pushing item on to the stack
//		Pushing item on to the stack
//		10->14->4
//		Poping from the stack
//		10->14
//		Peek of the stack
//		14
//		2
//		1
//		0
//		Stack is empty Now
//		Stack is Empty. Cannot be popped
//
//		----------------------------------------
//
//		Checking Stack with Generic dataType
//		Pushing item on to the stack
//		Pushing item on to the stack
//		Pushing item on to the stack
//		manoj->dheeraj->shashank
//		Poping from the stack
//		manoj->dheeraj
//		Peek of the stack
//		dheeraj
//		2
//		1
//		0
//		Stack is empty Now
//		Stack is Empty. Nothing to pop
//
//		----------------------------------------
//
//		Checking Queue with Int dataType
//		Inserting item into the Queue
//		Inserting item into the Queue
//		Inserting item into the Queue
//		Priniting intial Values
//		10->13->2
//		Dequeing from Stack
//		Removing item at the front : 10
//		13->2
//		Peek of the Queue
//		Returning the Top one
//		13
//		2
//		Removing item at the front : 13
//		1
//		Removing item at the front : 2
//		0
//		Queue is Empty Now
//
//		----------------------------------------
//
//		Checking Queue with Generic dataType
//		Inserting item into the Queue
//		Inserting item into the Queue
//		Inserting item into the Queue
//		Priniting intial Values
//		raja->pratheek->raviteja
//		Dequeing from Stack
//		Removing item at the front : raja
//		pratheek->raviteja
//		Peek of the Queue
//		Returning the Top one
//		pratheek
//		2
//		Removing item at the front : pratheek
//		1
//		Removing item at the front : raviteja
//		0
//		Queue is Empty Now		
		
		
	}

}
